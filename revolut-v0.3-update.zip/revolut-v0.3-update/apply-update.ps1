param(
    [string]$RepositoryPath = "C:\Users\novot\DCN-Python\revolut"
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

function Stop-WithMessage {
    param([string]$Message)
    Write-Host ""
    Write-Host "UPDATE STOPPED" -ForegroundColor Red
    Write-Host $Message -ForegroundColor Yellow
    exit 1
}

Write-Host "============================================================"
Write-Host " REVOLUTE v0.3 - Sandbox setup tools update"
Write-Host "============================================================"
Write-Host ""

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    Stop-WithMessage "Git was not found. Install or repair Git for Windows, then run this script again."
}
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    Stop-WithMessage "Node.js was not found. Install the project-approved Node.js version, then reopen PowerShell."
}
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
    Stop-WithMessage "npm was not found. Reinstall Node.js, then reopen PowerShell."
}

if (-not (Test-Path -LiteralPath $RepositoryPath -PathType Container)) {
    Stop-WithMessage "The repository folder was not found: $RepositoryPath"
}

$RepositoryPath = (Resolve-Path -LiteralPath $RepositoryPath).Path
$PatchPath = Join-Path $PSScriptRoot "0001-Add-beginner-Sandbox-setup-and-testing-tools.patch"
$ExpectedPatchHash = "2b34a84d7ab5b75bd86da7e8b758953a6844bc7df57bdede29219b744ad29d66"

if (-not (Test-Path -LiteralPath $PatchPath -PathType Leaf)) {
    Stop-WithMessage "The update patch is missing from the extracted update folder."
}

$ActualPatchHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $PatchPath).Hash.ToLowerInvariant()
if ($ActualPatchHash -ne $ExpectedPatchHash) {
    Stop-WithMessage "The update patch checksum does not match. Download and extract the update again."
}

Push-Location $RepositoryPath
try {
    $InsideWorkTree = (& git rev-parse --is-inside-work-tree 2>$null).Trim()
    if ($InsideWorkTree -ne "true") {
        Stop-WithMessage "The selected folder is not a Git repository."
    }

    $Branch = (& git branch --show-current).Trim()
    if ($Branch -ne "master") {
        Stop-WithMessage "The repository must be on branch master. It is currently on: $Branch"
    }

    $Changes = & git status --porcelain
    if ($Changes) {
        Stop-WithMessage "The repository has uncommitted changes. Commit or remove them before applying this update."
    }

    $NodeMajor = [int](& node -p "process.versions.node.split('.')[0]")
    if ($NodeMajor -lt 22) {
        Stop-WithMessage "Node.js 22 or newer is required. The installed major version is $NodeMajor."
    }

    Write-Host "Repository: $RepositoryPath"
    Write-Host "Branch: master"
    Write-Host "Patch checksum: verified"
    Write-Host ""
    Write-Host "Applying the tested update..."

    & git am --3way --keep-cr $PatchPath
    if ($LASTEXITCODE -ne 0) {
        & git am --abort 2>$null
        Stop-WithMessage "Git could not apply the update cleanly. The attempted git-am operation was aborted."
    }

    Write-Host ""
    Write-Host "Installing locked dependencies..."
    & npm ci --include=dev
    if ($LASTEXITCODE -ne 0) {
        Stop-WithMessage "The update commit was applied, but npm ci failed. Do not push yet; send the final error message to the maintainer."
    }

    Write-Host ""
    Write-Host "Running lint, type checks, reference checks, and tests..."
    & npm run check
    if ($LASTEXITCODE -ne 0) {
        Stop-WithMessage "The update commit was applied, but the verification tests failed. Do not push yet."
    }

    Write-Host ""
    Write-Host "Running the production TypeScript build..."
    & npm run build
    if ($LASTEXITCODE -ne 0) {
        Stop-WithMessage "The update commit was applied, but the TypeScript build failed. Do not push yet."
    }

    Write-Host ""
    Write-Host "UPDATE PASSED" -ForegroundColor Green
    Write-Host "The repository now contains the beginner Sandbox guide and helper menu."
    Write-Host ""
    & git log -1 --oneline
    Write-Host ""
    Write-Host "Next command:"
    Write-Host "  git push origin master" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "After pushing, the authorized tester can double-click:"
    Write-Host "  START-HERE-SANDBOX.cmd" -ForegroundColor Cyan
}
finally {
    Pop-Location
}
