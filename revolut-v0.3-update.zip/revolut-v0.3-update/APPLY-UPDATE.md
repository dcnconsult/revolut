# Apply the REVOLUTE v0.3 Sandbox helper update

## 1. Extract the ZIP

In File Explorer, right-click `revolut-v0.3-update.zip` and click **Extract All**.

## 2. Open PowerShell

Click Start, type `PowerShell`, and open Windows PowerShell.

## 3. Allow this local script for the current window

Copy, paste, and run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
```

## 4. Run the update

Change the first path below only if the ZIP was extracted somewhere else:

```powershell
& "$HOME\Downloads\revolut-v0.3-update\apply-update.ps1" `
  -RepositoryPath "C:\Users\novot\DCN-Python\revolut"
```

The script stops rather than overwrite uncommitted work. It verifies the patch checksum, applies one Git commit, installs dependencies, runs the full check, and runs the TypeScript build.

## 5. Push after `UPDATE PASSED`

```powershell
cd C:\Users\novot\DCN-Python\revolut
```

```powershell
git push origin master
```

## 6. Start the beginner setup

Open `C:\Users\novot\DCN-Python\revolut` in File Explorer and double-click:

```text
START-HERE-SANDBOX.cmd
```

Choose `1` for first-time Revolut Sandbox setup.
